/*************************************************************
 *  Booking.tsx
 *  This component allows a logged-in user to:
 *   1) Select a therapist
 *   2) Choose an available date and time
 *   3) Book an appointment
 *   4) View and cancel their existing appointments
 *
 *  It also includes optional logic to:
 *   - Check if a slot is still available prior to booking.
 *   - Remove the booked slot from the therapist's availability
 *     so that it doesn't appear again.
 *************************************************************/

import React, { useEffect, useState } from "react";
import {
  bookAppointment,
  getUserAppointments,
  getTherapists,
  getAvailableSlots,
  cancelAppointment,
  isSlotAvailable, // NEW: to check if slot is free
  removeBookedSlotFromTherapist, // NEW: remove a booked slot from therapist's schedule
} from "../services/firebaseService";
import { auth } from "../services/firebaseConfig";
import "../Styles/booking.css"; // Import CSS file
import Swal from "sweetalert2";
import "sweetalert2/dist/sweetalert2.css"; // optional if we need default styling

/*************************************************************
 *  Booking Component
 *************************************************************/
const Booking = () => {
  /*************************************************************
   *  STATE
   *************************************************************/
  const [appointments, setAppointments] = useState<any[]>([]);
  const [therapists, setTherapists] = useState<any[]>([]);
  const [selectedTherapist, setSelectedTherapist] = useState("");
  const [availableDates, setAvailableDates] = useState<string[]>([]);
  const [selectedDate, setSelectedDate] = useState("");
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);
  const [selectedTime, setSelectedTime] = useState("");

  // Firebase Auth user (if logged in)
  const user = auth.currentUser;

  /*************************************************************
   *  EFFECT: Fetch data when the component mounts or user changes
   *************************************************************/
  useEffect(() => {
    if (user) {
      fetchAppointments();
    }
    fetchTherapistsList();
  }, [user]);

  /*************************************************************
   *  FETCH FUNCTIONS
   *************************************************************/

  /**
   *  Fetches all appointments for the currently logged-in user.
   *  Called upon component mount if user is present.
   */
  const fetchAppointments = async () => {
    if (!user) return;
    try {
      const data = await getUserAppointments(user.uid);
      setAppointments(data);
    } catch (error) {
      console.error("Error fetching user appointments:", error);
    }
  };

  /**
   *  Fetches the list of available therapists from Firestore.
   */
  const fetchTherapistsList = async () => {
    try {
      const data = await getTherapists();
      setTherapists(data);
    } catch (error) {
      console.error("Error fetching therapists:", error);
    }
  };

  /*************************************************************
   *  HANDLERS
   *************************************************************/

  /**
   *  Handles therapist selection and fetches their availability slots.
   *  Resets any previously selected date or time.
   *
   *  @param {string} therapistId - Selected therapist's ID
   */
  const handleTherapistChange = async (therapistId: string) => {
    setSelectedTherapist(therapistId);
    setSelectedDate("");
    setAvailableTimes([]);

    try {
      // "slots" is an array of objects like [{ day: "Monday", slots: ["10:00 AM", ...] }, ...]
      const slots = await getAvailableSlots(therapistId);

      // Collect just the 'day' portion for the user to pick from
      const distinctDays = slots.map((slot) => slot.day);
      setAvailableDates(distinctDays);
    } catch (error) {
      console.error("Error fetching available slots:", error);
    }
  };

  /**
   *  Handles date selection: sets the chosen date and then
   *  filters out the array of time slots for that day.
   *
   *  @param {string} date - Selected appointment date (e.g. "Monday")
   */
  const handleDateChange = async (date: string) => {
    setSelectedDate(date);

    try {
      const slots = await getAvailableSlots(selectedTherapist);
      // Filter to find the object where day === selected date
      const matchedObj = slots.find((slotObj) => slotObj.day === date);
      setAvailableTimes(matchedObj ? matchedObj.slots : []);
    } catch (error) {
      console.error("Error setting selected date:", error);
    }
  };

  /**
   *  Handles the actual booking process:
   *   1) Checks if user, therapist, date, time are selected
   *   2) Confirms with user
   *   3) (Optional) Check if slot is still available
   *   4) Books appointment
   *   5) (Optional) Remove booked slot from therapist's availability
   *   6) Re-fetch the user's appointments
   */
  const handleBookAppointment = async () => {
    if (!user || !selectedTherapist || !selectedDate || !selectedTime) {
      Swal.fire({
        icon: "warning",
        title: "Please select a therapist, date, and time first",
        confirmButtonText: "OK",
      });
      return;
    }

    // Confirm with the user
    const confirmBooking = window.confirm(
      `Confirm appointment on ${selectedDate} at ${selectedTime}?`
    );
    if (!confirmBooking) return;

    try {
      /*************************************************************
       *  Optional: Check if the slot is still free.
       *  If you do not want to do this, you can skip the step.
       *************************************************************/
      const slotFree = await isSlotAvailable(
        selectedTherapist,
        selectedDate,
        selectedTime
      );
      if (!slotFree) {
        alert("Sorry, this slot has just been taken. Please select another.");
        return; // Stop if the slot is not free
      }

      /*************************************************************
       *  Book the appointment in Firestore
       *************************************************************/
      await bookAppointment(
        user.uid,
        selectedTherapist,
        selectedDate,
        selectedTime
      );

      /*************************************************************
       *  Optional: Remove the booked slot from the therapist's
       *  availability so it's not shown in the future.
       *************************************************************/
      await removeBookedSlotFromTherapist(
        selectedTherapist,
        selectedDate,
        selectedTime
      );
      Swal.fire({
        icon: "success",
        title: "Appointment booked successfully",
        confirmButtonText: "OK",
      });

      // Re-fetch the user's appointments so we see the new one
      fetchAppointments();
    } catch (error) {
      console.error("Booking failed:", error);
    }
  };

  /**
   *  Cancels a given appointment by doc ID.
   *  Then refresh the user's appointments to reflect changes.
   */
  const handleCancelAppointment = async (appointmentId: string) => {
    try {
      const confirmCancel = window.confirm("Are you sure you want to cancel?");
      if (!confirmCancel) return;

      await cancelAppointment(appointmentId);
      // Re-fetch appointments after cancelation
      fetchAppointments();
    } catch (error) {
      console.error("Error canceling appointment:", error);
    }
  };

  /*************************************************************
   *  RENDER
   *************************************************************/
  return (
    <div className="booking-container">
      <h2 className="booking-title">Book an Appointment</h2>

      {/* Therapist Selection */}
      <select
        onChange={(e) => handleTherapistChange(e.target.value)}
        className="input-field"
        value={selectedTherapist}
      >
        <option value="">Select a Therapist</option>
        {therapists.map((therapist) => (
          <option key={therapist.therapistId} value={therapist.therapistId}>
            {therapist.name} - {therapist.specialization}
          </option>
        ))}
      </select>

      {/* Date Selection */}
      <select
        onChange={(e) => handleDateChange(e.target.value)}
        className="input-field"
        disabled={!selectedTherapist}
        value={selectedDate}
      >
        <option value="">Select a Date</option>
        {availableDates.map((date) => (
          <option key={date} value={date}>
            {date}
          </option>
        ))}
      </select>

      {/* Time Slot Selection */}
      <select
        onChange={(e) => setSelectedTime(e.target.value)}
        className="input-field"
        disabled={!selectedDate}
        value={selectedTime}
      >
        <option value="">Select a Time Slot</option>
        {availableTimes.map((time) => (
          <option key={time} value={time}>
            {time}
          </option>
        ))}
      </select>

      {/* Book Button */}
      <button onClick={handleBookAppointment} className="button">
        Book Now
      </button>

      {/* Appointments List */}
      <h2 className="booking-title">Your Appointments</h2>
      <div className="appointment-list">
        {appointments.map((appointment) => (
          <div key={appointment.id} className="appointment-item">
            <div>
              <p>
                <strong>Date:</strong> {appointment.date}
              </p>
              <p>
                <strong>Time:</strong> {appointment.time}
              </p>
              <p>
                <strong>Therapist ID:</strong> {appointment.therapistId}
              </p>
              <p>
                <strong>Status:</strong> {appointment.status}
              </p>
            </div>
            {/* Cancel Button */}
            <button
              onClick={() => handleCancelAppointment(appointment.id)}
              className="cancel-button"
            >
              Cancel
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Booking;
