/*************************************************************
 *  Admin.tsx
 *  This component serves as the admin dashboard where
 *  you can register new therapists, list therapists,
 *  view their availability, and see all appointments.
 *************************************************************/

import React, { useEffect, useState } from "react";
import {
  getTherapists,
  getAvailableSlots,
  registerUser,
  addTherapistToFirestore,
  getAllAppointments, // NEW: fetch all appointments instead of a single user's
} from "../services/firebaseService";
import "../Styles/Admin.css";
import Swal from "sweetalert2";
import "sweetalert2/dist/sweetalert2.css"; // optional if we need default styling

/*************************************************************
 *  Admin Component
 *************************************************************/
const Admin = () => {
  /*************************************************************
   *  STATE DECLARATIONS
   *************************************************************/
  const [therapists, setTherapists] = useState<any[]>([]);
  const [slots, setSlots] = useState<any[]>([]);

  // Replacing "users" array with "appointments" to store all user appointments
  const [appointments, setAppointments] = useState<any[]>([]);

  // State for new therapist details
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [availableDays, setAvailableDays] = useState<string[]>([]);
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);

  /*************************************************************
   *  EFFECT HOOKS
   *  Automatically fetch therapists on component mount.
   *************************************************************/
  useEffect(() => {
    fetchTherapistsData();
  }, []);

  /*************************************************************
   *  FETCHING FUNCTIONS
   *************************************************************/

  /**
   * Fetch all therapists from Firestore and store in state.
   */
  const fetchTherapistsData = async () => {
    try {
      const data = await getTherapists();
      setTherapists(data);
    } catch (error) {
      console.error("Error fetching therapists:", error);
    }
  };

  /**
   * Given a therapistId, fetch their availability slots.
   * The service now returns an array of { day, slots } objects.
   * We'll store that in state.
   */
  const fetchSlots = async (therapistId: string) => {
    try {
      const slotsData = await getAvailableSlots(therapistId);
      setSlots(slotsData);
    } catch (error) {
      console.error("Error fetching slots:", error);
    }
  };

  /**
   * Fetch ALL appointments (for all users) using getAllAppointments()
   * This is more appropriate for admin than fetching a single user's data.
   */
  const fetchAllAppointments = async () => {
    try {
      const all = await getAllAppointments();
      setAppointments(all);
    } catch (error) {
      console.error("Error fetching all appointments:", error);
    }
  };

  /*************************************************************
   *  ADD THERAPIST
   *************************************************************/
  const handleAddTherapist = async () => {
    // Basic validation to ensure all fields are filled
    if (
      !email ||
      !password ||
      !name ||
      !specialization ||
      availableDays.length === 0 ||
      availableTimes.length === 0
    ) {
      Swal.fire({
        icon: "error",
        title: "Empty fields",
        text: `Please fill all fields before adding a therapist`,
        confirmButtonText: "OK",
      });
      return;
    }

    try {
      // 1) Register therapist in Firebase Auth with role "therapist"
      const newTherapist = await registerUser(email, password, "therapist");
      const therapistId = newTherapist.uid; // Unique ID from Firebase Auth

      // 2) Build the availability array to match the new schema
      //    Each day + the full array of time slots.
      const availability = availableDays.map((day) => ({
        day,
        slots: availableTimes,
      }));

      // 3) Store therapist details in Firestore under "therapists/{therapistId}"
      await addTherapistToFirestore(therapistId, {
        name,
        email,
        specialization,
        availability,
      });

      Swal.fire({
        icon: "success",
        title: "Therapist Added",
        text: `${name} was added successfully!`,
        confirmButtonText: "OK",
      });

      // 4) Refresh therapist list to include the newly added one
      fetchTherapistsData();
    } catch (error) {
      console.error("Error adding therapist:", error);
    }
  };

  /*************************************************************
   *  RENDERING
   *************************************************************/
  return (
    <div className="admin-container">
      <h2 className="admin-title">Admin Dashboard</h2>

      {/************************************************
       * SECTION: ADD NEW THERAPIST
       *************************************************/}
      <div className="section add-therapist-section">
        <h3>Add New Therapist</h3>

        <input
          type="text"
          placeholder="Full Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input-field"
        />
        <input
          type="text"
          placeholder="Specialization"
          value={specialization}
          onChange={(e) => setSpecialization(e.target.value)}
          className="input-field"
        />
        <input
          type="email"
          placeholder="Therapist Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />

        {/* Available Days Selection */}
        <label className="input-label">Available Days:</label>
        <select
          multiple // Allow selecting multiple days
          onChange={(e) =>
            setAvailableDays(
              Array.from(e.target.selectedOptions).map((o) => o.value)
            )
          }
          className="input-field"
        >
          <option value="Monday">Monday</option>
          <option value="Tuesday">Tuesday</option>
          <option value="Wednesday">Wednesday</option>
          <option value="Thursday">Thursday</option>
          <option value="Friday">Friday</option>
        </select>

        {/* Available Time Slots */}
        <label className="input-label">Available Time Slots:</label>
        <input
          type="text"
          placeholder="e.g., 10:00 AM, 2:00 PM"
          value={availableTimes.join(", ")}
          onChange={(e) =>
            setAvailableTimes(
              e.target.value.split(",").map((time) => time.trim())
            )
          }
          className="input-field"
        />

        <button
          onClick={handleAddTherapist}
          className="button add-therapist-button"
        >
          Add Therapist
        </button>
      </div>

      {/************************************************
       * SECTION: THERAPISTS LIST
       *************************************************/}
      <div className="section therapists-list-section">
        <h3>Therapists List</h3>
        <ul className="therapists-list">
          {therapists.map((therapist) => (
            <li key={therapist.therapistId}>
              <span className="therapist-info">
                {therapist.name} - {therapist.specialization}
              </span>
              <button
                onClick={() => fetchSlots(therapist.therapistId)}
                className="small-button"
              >
                View Availability
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/************************************************
       * SECTION: AVAILABLE SLOTS
       *************************************************/}
      <div className="section slots-section">
        <h3>Therapist Availability</h3>
        {slots.length > 0 ? (
          <ul className="slots-list">
            {slots.map((slotObj: any, index: number) => (
              <li key={index}>
                {/* Display "Monday: 10:00 AM, 2:00 PM" etc. */}
                <strong>{slotObj.day}:</strong> {slotObj.slots.join(", ")}
              </li>
            ))}
          </ul>
        ) : (
          <p>No slots available (or not fetched yet)</p>
        )}
      </div>

      {/************************************************
       * SECTION: ALL APPOINTMENTS
       *************************************************/}
      <div className="section appointments-section">
        <h3>All Appointments</h3>
        {/* Button to fetch all appointments from Firestore */}
        <button onClick={fetchAllAppointments} className="button">
          Get All Appointments
        </button>
        {appointments.length > 0 && (
          <ul className="appointments-list">
            {appointments.map((ap) => (
              <li key={ap.id}>
                <span>
                  <strong>UserID:</strong> {ap.userId} |{" "}
                  <strong>Therapist:</strong> {ap.therapistId} |{" "}
                  <strong>Date:</strong> {ap.date} | <strong>Time:</strong>{" "}
                  {ap.time} | <strong>Status:</strong> {ap.status}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Admin;
