/*************************************************************
 *  firebaseService.ts
 *  This file contains all Firestore + Auth interactions.
 *  We store user data in the "users" collection,
 *  therapist data in the "therapists" collection,
 *  and appointment data in the "appointments" collection.
 * 
 *  NOTE: You can add or refine these functions as your
 *  requirements grow (e.g., add more complex scheduling, etc.).
 *************************************************************/

import { db, auth } from "./firebaseConfig"; // Import Firestore + Auth
import {
  collection,
  addDoc,
  getDocs,
  doc,
  setDoc,
  deleteDoc,
  query,
  where,
  getDoc,
  updateDoc,
  DocumentData,
} from "firebase/firestore"; // Firestore functions
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  User,
  UserCredential,
} from "firebase/auth"; // Auth functions

/*************************************************************
 *  INTERFACES & TYPES
 *  These help ensure consistent shape of data across our app.
 *************************************************************/

/** Represents a generic user’s information in Firestore. */
interface IUserProfile {
  uid: string;           // Same as Firebase Auth user id
  email: string;
  displayName?: string;  // We can store user's name
  role: "user" | "admin" | "therapist"; // Distinguish between roles
}

/** Represents a Therapist’s document structure in Firestore. */
interface ITherapist {
  name: string;
  email: string;
  specialization?: string;
  availableDays?: string[];
  availableTimes?: string[];
  availability?: IAvailability[];
  // we can store more fields as needed (photoURL, phone, etc.).
}

/** Represents an Availability structure (day + time slots). */
interface IAvailability {
  day: string;
  slots: string[];
}

/** Represents an Appointment document in Firestore. */
interface IAppointment {
  id?: string;           // Firestore doc ID
  userId: string;        // The user who booked
  therapistId: string;   // The therapist assigned
  date: string;          // e.g. "2025-03-05"
  time: string;          // e.g. "10:00 AM"
  status?: "booked" | "canceled" | "completed"; // or any other statuses
}

/*************************************************************
 *  EMAIL VALIDATION HELPERS
 *************************************************************/

/**
 * Validate email format before registering/logging in.
 * Using a simple regex for demonstration.
 * @param {string} email - Email to validate
 * @returns {boolean} true if valid format
 */
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/*************************************************************
 *  AUTHENTICATION & USER PROFILE FUNCTIONS
 *************************************************************/

/**
 * Creates a user doc in Firestore under "users" collection.
 * We call this after successful sign-up to store user details
 * (e.g., email, role).
 *
 * @param {string} uid - Firebase Auth user ID
 * @param {string} email - User email
 * @param {"user" | "admin" | "therapist"} role - Role of this user
 * @param {string} [displayName] - Optional user display name
 */
export const createUserProfile = async (
  uid: string,
  email: string,
  role: "user" | "admin" | "therapist" = "user",
  displayName?: string
) => {
  const userRef = doc(db, "users", uid);
  const userData: IUserProfile = {
    uid,
    email,
    role,
    displayName,
  };
  await setDoc(userRef, userData);
};

/**
 * Fetches a single user's profile from Firestore "users" collection.
 * Useful for checking role, displayName, etc.
 *
 * @param {string} uid - User's unique ID
 * @returns {Promise<IUserProfile | null>} Returns user doc or null if not found
 */
export const getUserProfile = async (uid: string): Promise<IUserProfile | null> => {
  const userRef = doc(db, "users", uid);
  const snapshot = await getDoc(userRef);
  if (!snapshot.exists()) return null;
  return snapshot.data() as IUserProfile;
};
/**
 * Register a new user in Firebase Auth, then create a Firestore doc.
 * @param {string} email - User's email
 * @param {string} password - User's password
 * @param {"user" | "admin" | "therapist"} [role="user"] - Assign role (defaults to "user")
 * @param {string} [displayName] - Optional display name
 * @returns {Promise<User>} Returns the newly created Auth user object
 */
export const registerUser = async (
  email: string,
  password: string,
  role: "user" | "admin" | "therapist" = "user",
  displayName?: string
): Promise<User> => {
  try {
    if (!isValidEmail(email)) {
      throw new Error("Invalid email format");
    }
    
    // Create user in Firebase Authentication
    const userCredential: UserCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );
    const newUser = userCredential.user;

    // Create user doc in "users" collection, excluding displayName if undefined
    const userRef = doc(db, "users", newUser.uid);
    const userData: any = {
      uid: newUser.uid,
      email: newUser.email || "",
      role,
    };

    if (displayName) {
      userData.displayName = displayName; // Only add displayName if provided
    }

    await setDoc(userRef, userData);

    return newUser;
  } catch (error) {
    console.error("Error registering user:", error);
    throw error;
  }
};

/**
 * Authenticate (log in) a user by email and password.
 * @param {string} email - User's email
 * @param {string} password - User's password
 * @returns {Promise<User>} - Returns the authenticated user object
 */
export const loginUser = async (email: string, password: string): Promise<User> => {
  try {
    if (!isValidEmail(email)) {
      throw new Error("Invalid email format");
    }
    const userCredential: UserCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );
    return userCredential.user;
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
};

/**
 * Logs out the currently authenticated user from Firebase Auth.
 */
export const logoutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
    console.log("User logged out");
  } catch (error) {
    console.error("Error logging out:", error);
    throw error;
  }
};

/*************************************************************
 *  APPOINTMENTS & BOOKING FUNCTIONS
 *************************************************************/

/**
 * Books (creates) an appointment document in Firestore.
 * If you want to prevent double-booking, you should first
 * check if the slot is already taken (see optional check below).
 *
 * @param {string} userId - ID of the user making the appointment
 * @param {string} therapistId - ID of the therapist
 * @param {string} date - Appointment date (format: YYYY-MM-DD)
 * @param {string} time - Appointment time (e.g., "10:00 AM")
 * @returns {Promise<void>} - Resolves when the appointment is created
 */
export const bookAppointment = async (
  userId: string,
  therapistId: string,
  date: string,
  time: string
): Promise<void> => {
  // OPTIONAL: Here you can call "isSlotAvailable" to ensure no conflict.
  // If conflict, throw an Error.

  await addDoc(collection(db, "appointments"), {
    userId,
    therapistId,
    date,
    time,
    status: "booked",
  });
};

/**
 * Checks whether a given date/time is still available for a therapist.
 * This is optional but recommended to avoid double-booking.
 *
 * @param {string} therapistId
 * @param {string} date
 * @param {string} time
 * @returns {Promise<boolean>} true if the slot is free
 */
export const isSlotAvailable = async (
  therapistId: string,
  date: string,
  time: string
): Promise<boolean> => {
  const q = query(
    collection(db, "appointments"),
    where("therapistId", "==", therapistId),
    where("date", "==", date),
    where("time", "==", time)
  );
  const snapshot = await getDocs(q);
  // If no docs found => it's available
  return snapshot.empty;
};

/**
 * Retrieves all appointments for a given user.
 * @param {string} userId - ID of the user
 * @returns {Promise<IAppointment[]>} - Array of user's appointments
 */
export const getUserAppointments = async (
  userId: string
): Promise<IAppointment[]> => {
  const q = query(collection(db, "appointments"), where("userId", "==", userId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...(doc.data() as IAppointment),
  }));
};

/**
 * Retrieves ALL appointments from the "appointments" collection.
 * Useful for admin usage or analytics.
 * @returns {Promise<IAppointment[]>} - Array of all appointments
 */
export const getAllAppointments = async (): Promise<IAppointment[]> => {
  const snapshot = await getDocs(collection(db, "appointments"));
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...(doc.data() as IAppointment),
  }));
};

/**
 * Cancels an appointment by deleting it from Firestore.
 * @param {string} appointmentId - ID of the appointment to be canceled
 */
export const cancelAppointment = async (appointmentId: string): Promise<void> => {
  await deleteDoc(doc(db, "appointments", appointmentId));
};

/*************************************************************
 *  THERAPIST FUNCTIONS
 *************************************************************/

/**
 * Fetches all therapists from the "therapists" collection.
 * @returns {Promise<ITherapistWithId[]>} - Array of therapists with doc ID
 */
export interface ITherapistWithId extends ITherapist {
  therapistId: string;
}
export const getTherapists = async (): Promise<ITherapistWithId[]> => {
  const snapshot = await getDocs(collection(db, "therapists"));
  return snapshot.docs.map((doc) => ({
    therapistId: doc.id,
    ...(doc.data() as ITherapist),
  }));
};

/**
 * Retrieves available slots for a given therapist.
 * This assumes each therapist doc has something like:
 * {
 *   name: "...",
 *   email: "...",
 *   availability: [
 *      { day: 'Monday', slots: ['10:00 AM', '2:00 PM'] }, ...
 *   ]
 * }
 * Adjust as needed for your actual schema.
 *
 * @param {string} therapistId - ID of the therapist
 * @returns {Promise<IAvailability[]>} - Array of day + slots
 */
export const getAvailableSlots = async (
  therapistId: string
): Promise<IAvailability[]> => {
  const therapistRef = doc(db, "therapists", therapistId);
  const snapshot = await getDoc(therapistRef);

  // If doc doesn't exist or has no availability field, return empty
  if (!snapshot.exists()) return [];
  const data = snapshot.data() as Partial<ITherapist> & {
    availability?: IAvailability[];
  };
  return data.availability || [];
};

/**
 * Adds (or overrides) a therapist doc in Firestore.
 * If you call this the first time for a new therapist,
 * it creates the doc. If you call again with the same ID,
 * it updates the doc's data.
 *
 * @param {string} therapistId - Therapist ID
 * @param {ITherapist} therapistData - Therapist details
 */
export const addTherapistToFirestore = async (
  therapistId: string,
  therapistData: ITherapist
): Promise<void> => {
  const therapistRef = doc(db, "therapists", therapistId);
  await setDoc(therapistRef, therapistData, { merge: true });
};

/**
 * Updates a therapist’s availability (e.g., removing a booked slot).
 * After a successful booking, you can remove that slot from
 * the therapist’s availability so it’s no longer visible.
 *
 * @param {string} therapistId
 * @param {string} day
 * @param {string} time
 * @returns {Promise<void>}
 */
export const removeBookedSlotFromTherapist = async (
  therapistId: string,
  day: string,
  time: string
): Promise<void> => {
  const therapistRef = doc(db, "therapists", therapistId);
  const snapshot = await getDoc(therapistRef);
  if (!snapshot.exists()) return;

  const data = snapshot.data() as ITherapist & {
    availability?: IAvailability[];
  };
  const { availability = [] } = data;

  // Go through each day, remove the matching time slot.
  const updatedAvailability = availability.map((item) => {
    if (item.day === day) {
      return {
        ...item,
        slots: item.slots.filter((slot) => slot !== time),
      };
    }
    return item;
  });

  // Write updated availability back to Firestore
  await updateDoc(therapistRef, { availability: updatedAvailability });
};
