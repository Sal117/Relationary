/*************************************************************
 * Auth.tsx
 * Allows the user to either sign up or log in.
 * Uses our custom Firebase service functions to handle
 * registration and login instead of calling Firebase directly.
 *************************************************************/

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../Styles/Auth.css"; // Auth page CSS

// Import the new firebaseService methods
import { loginUser, registerUser } from "../services/firebaseService";

const Auth = () => {
  // Form state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);

  // Error handling (display errors in UI)
  const [error, setError] = useState("");

  // For navigation after successful auth
  const navigate = useNavigate();

  /**
   * Handle user authentication (signup or login).
   */
  const handleAuth = async () => {
    try {
      // Clear any previous error
      setError("");

      if (isSignUp) {
        /*************************************************************
         * Register a new user with default role = "user"
         * This automatically creates the user doc in "users" collection.
         *************************************************************/
        await registerUser(email, password, "user");
      } else {
        /*************************************************************
         * Logs in the user using the firebaseService loginUser()
         *************************************************************/
        await loginUser(email, password);
      }

      // Redirect after successful login or signup
      navigate("/booking");
    } catch (err: any) {
      setError(err.message || "Authentication failed");
    }
  };

  return (
    <div className="auth-container">
      <h2>{isSignUp ? "Sign Up" : "Login"}</h2>

      {/* Error display */}
      {error && <p className="error-message">{error}</p>}

      {/* Email Field */}
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="input-field"
      />

      {/* Password Field */}
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="input-field"
      />

      {/* Primary Auth Button */}
      <button onClick={handleAuth} className="button">
        {isSignUp ? "Sign Up" : "Login"}
      </button>

      {/* Switch between Sign-Up and Login */}
      <p onClick={() => setIsSignUp(!isSignUp)} className="toggle-link">
        {isSignUp
          ? "Already have an account? Login"
          : "Don't have an account? Sign Up"}
      </p>
    </div>
  );
};

export default Auth;
